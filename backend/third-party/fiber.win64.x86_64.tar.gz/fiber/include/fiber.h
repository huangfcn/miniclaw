#ifndef __FIBER_H__
#define __FIBER_H__

#ifdef __cplusplus
extern "C" {
#endif
#include <stdint.h>

struct FibTCB;
typedef struct FibTCB FibTCB;
typedef struct FibTCB * fiber_t;

///////////////////////////////////////////////////////////////////
/* coroutine lib standard APIs:                                  */
/* 1. libary initialization                                      */
/* 2. create a task                                              */
/* 3. yield                                                      */
/* 4. resume                                                     */
/* ------------------------------------------------------------- */
/* 5. usleep (task level usleep, wont hangup the thread)         */
/* 6. sched_yield                                                */
///////////////////////////////////////////////////////////////////
/* called @ system startup */
bool FiberGlobalStartup();
bool FiberThreadStartup();

/* create a task */
FibTCB * fiber_create(
    void *(*func)(void *), 
    void * args, 
    void * stackaddr, 
    uint32_t stacksize
    );

/* yield will yield control to other task
 * current task will suspend until resume called on it
 */
FibTCB * fiber_suspend(uint64_t code);
uint64_t fiber_resume(FibTCB * the_task);

/* identify current running task */
FibTCB * fiber_ident();

/* task usleep (accurate at ms level)*/
void fiber_usleep(int usec);

/* same functionality of sched_yield, yield the processor
 * sched_yield causes the calling task to relinquish the CPU.
 * The task is moved to the end of the ready queue and 
 * a new task gets to run.
 */
FibTCB * fiber_yield(uint64_t);

/* service thread (scheduler) entry point*/
void * fiber_thread_entry(void * args);
///////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////
/* Extensions: Fiber Local Data and Callbacks                          */
/////////////////////////////////////////////////////////////////////////
bool fiber_set_localdata(FibTCB * the_task, int index, uint64_t data);
uint64_t fiber_get_localdata(FibTCB * the_task, int index);
bool fiber_install_callbacks(
    FibTCB * the_task,
    bool (* onTaskStartup)(FibTCB *),
    bool (* onTaskCleanup)(FibTCB *)
);

/////////////////////////////////////////////////////////////////////////
/* Scheduler callback args                                             */
/////////////////////////////////////////////////////////////////////////
typedef struct {
    bool (*fiberSchedulerCallback)(void *);
    void * args;
} fibthread_args_t, fiber_scheduler_args_t;
/////////////////////////////////////////////////////////////////////////

#ifdef __cplusplus
}
#endif

#endif